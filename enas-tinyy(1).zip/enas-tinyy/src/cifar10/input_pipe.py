"""
Tiny ImageNet: Input Pipeline
Written by Patrick Coady (pcoady@alum.mit.edu)

Reads in jpegs, distorts images (flips, translations, hue and
saturation) and builds QueueRunners to keep the GPU well-fed. Uses
specific directory and file naming structure from data download
link below.

Also builds dictionary between label integer and human-readable
class names.

Get data here:
https://tiny-imagenet.herokuapp.com/
"""
import cv2
import glob
import re
import tensorflow as tf
import random
import numpy as np


def load_filenames_labels(mode, _path):
  """Gets filenames and labels

  Args:
    mode: 'train' or 'val'
      (Directory structure and file naming different for
      train and val datasets)

  Returns:
    list of tuples: (jpeg filename with path, label)
  """
  label_dict, class_description = build_label_dicts(_path)
  filenames_labels = []
  if mode == 'train':
    filenames = glob.glob(_path+'/tiny-imagenet-200/train/*/images/*.JPEG')
    for filename in filenames:
      match = re.search(r'n\d+', filename)
      label = str(label_dict[match.group()])
      filenames_labels.append((filename, label))
  elif mode == 'val':
    with open(_path+'/tiny-imagenet-200/val/val_annotations.txt', 'r') as f:
      for line in f.readlines():
        split_line = line.split('\t')
        filename = _path+'/tiny-imagenet-200/val/images/' + split_line[0]
        label = str(label_dict[split_line[1]])
        filenames_labels.append((filename, label))

  return filenames_labels


def build_label_dicts(_path):
  """Build look-up dictionaries for class label, and class description

  Class labels are 0 to 199 in the same order as 
    tiny-imagenet-200/wnids.txt. Class text descriptions are from 
    tiny-imagenet-200/words.txt

  Returns:
    tuple of dicts
      label_dict: 
        keys = synset (e.g. "n01944390")
        values = class integer {0 .. 199}
      class_desc:
        keys = class integer {0 .. 199}
        values = text description from words.txt
  """
  label_dict, class_description = {}, {}
  with open(_path+'/tiny-imagenet-200/wnids.txt', 'r') as f:
    tmp = []
    for i, line in enumerate(f.readlines()):
      synset = line[:-1]  # remove \n
      tmp.append(synset)

    tmp.sort()  # 字典序

    for i,synset in enumerate(tmp):
      label_dict[synset] = i

  with open(_path+'/tiny-imagenet-200/words.txt', 'r') as f:
    for i, line in enumerate(f.readlines()):
      synset, desc = line.split('\t')
      desc = desc[:-1]  # remove \n
      if synset in label_dict:
        class_description[label_dict[synset]] = desc

  return label_dict, class_description


def read_image(filename_q, mode):
  """Load next jpeg file from filename / label queue
  Randomly applies distortions if mode == 'train' (including a 
  random crop to [56, 56, 3]). Standardizes all images.

  Args:
    filename_q: Queue with 2 columns: filename string and label string.
     filename string is relative path to jpeg file. label string is text-
     formatted integer between '0' and '199'
    mode: 'train' or 'val'

  Returns:
    [img, label]: 
      img = tf.uint8 tensor [height, width, channels]  (see tf.image.decode.jpeg())
      label = tf.unit8 target class label: {0 .. 199}
  """
  item = filename_q.dequeue()
  filename = item[0]
  label = item[1]
  file = tf.read_file(filename)

  img = tf.image.decode_jpeg(file, channels=3)
  # image distortions: left/right, random hue, random color saturation
  if mode == 'train':
    img = tf.random_crop(img, np.array([56, 56, 3]))
    img = tf.image.random_flip_left_right(img)
    # val accuracy improved without random hue
    # img = tf.image.random_hue(img, 0.05)
    img = tf.image.random_saturation(img, 0.5, 2.0)
  else:
    img = tf.image.crop_to_bounding_box(img, 4, 4, 56, 56)

  label = tf.string_to_number(label, tf.int32)
  label = tf.cast(label, tf.uint8)

  return [img, label]

def batch_q(mode, config):
  """Return batch of images using filename Queue

  Args:
    mode: 'train' or 'val'
    config: training configuration object

  Returns:
    imgs: tf.uint8 tensor [batch_size, height, width, channels]
    labels: tf.uint8 tensor [batch_size,]

  """
  filenames_labels = load_filenames_labels(mode, 'XX')
  random.shuffle(filenames_labels)
  filename_q = tf.train.input_producer(filenames_labels,
                                       num_epochs=config.num_epochs,
                                       shuffle=True)

  # 2 read_image threads to keep batch_join queue full:
  return tf.train.batch_join([read_image(filename_q, mode) for i in range(2)],
                             config.batch_size, shapes=[(56, 56, 3), ()],
                             capacity=2048)

def get_data_mode_ss(mode, _path, fff):
  filenames_labels = load_filenames_labels(mode, _path)
  random.shuffle(filenames_labels)
  if fff == 'pjs':
    filename_q1 = tf.train.input_producer(filenames_labels[:90000],
                                       num_epochs=999,
                                       shuffle=True)
    filename_q2 = tf.train.input_producer(filenames_labels[90000:],
                                          num_epochs=999,
                                          shuffle=True)
  else:
    filename_q1 = tf.train.input_producer(filenames_labels,
                                          num_epochs=999,
                                          shuffle=True)
    filename_q2 = None
  return filename_q1, filename_q2

def get_data_mode_test(mode, _path):
  filenames_labels = load_filenames_labels(mode, _path)
  random.shuffle(filenames_labels)
  filename_q = tf.train.input_producer(filenames_labels,
                                          num_epochs=999,
                                          shuffle=True)
  return filename_q

def read_imagee(filename_q, mode):
  item = filename_q.dequeue()
  filename = item[0]
  label = item[1]
  file = tf.read_file(filename)

  img = tf.image.decode_jpeg(file, channels=3)

  # mean: [30666.809 28408.203 27136.014]
  # std: [18776.324 17553.832 17653.902]
  me = np.array([30666.809,28408.203,27136.014])
  st = np.array([18776.324,17553.832,17653.902])

  img = img-me/st


  def _pre_process(x):
    x = tf.pad(x, [[4, 4], [4, 4], [0, 0]])
    x = tf.random_crop(x, [64, 64, 3])
    x = tf.image.random_flip_left_right(x)

    mask = tf.ones([5, 5], dtype=tf.int32)
    start = tf.random_uniform([2], minval=0, maxval=64, dtype=tf.int32)
    mask = tf.pad(mask, [[5 + start[0], 64 - start[0]],
                         [5 + start[1], 64 - start[1]]])
    mask = mask[5: 5 + 64,
           5: 5 + 64]
    mask = tf.reshape(mask, [64, 64, 1])
    mask = tf.tile(mask, [1, 1, 3])
    x = tf.where(tf.equal(mask, 0), x=x, y=tf.zeros_like(x))

    return x

  if mode == 'train':
    img = _pre_process(img)
  # image distortions: left/right, random hue, random color saturation
  # if mode == 'train':
  #   img = tf.random_crop(img, np.array([56, 56, 3]))
  #   img = tf.image.random_flip_left_right(img)
  #   # val accuracy improved without random hue
  #   # img = tf.image.random_hue(img, 0.05)
  #   img = tf.image.random_saturation(img, 0.5, 2.0)
  # else:
  #   img = tf.image.crop_to_bounding_box(img, 4, 4, 56, 56)

  label = tf.string_to_number(label, tf.int32)
  label = tf.cast(label, tf.int32)
  img = tf.cast(img, tf.float32)
  return (img, label)

def get_data_mode_tmp(mode, _path, _num_classes):
  '''
  Args:
  mode: 'train' or 'val'
  '''

  filenames_labels = load_filenames_labels(mode, _path)
  random.shuffle(filenames_labels)

  res_img = []
  res_label = []

  with tf.Session() as sess:
    for item in filenames_labels:

      filename = item[0]
      # print(type(item[1]))
      label = int(item[1])
      file = tf.read_file(filename)

      img = tf.image.decode_jpeg(file, channels=3)
      # image distortions: left/right, random hue, random color saturation
      # if mode == 'train':
      #   img = tf.random_crop(img, np.array([56, 56, 3]))
      #   img = tf.image.random_flip_left_right(img)
      #   # val accuracy improved without random hue
      #   # img = tf.image.random_hue(img, 0.05)
      #   img = tf.image.random_saturation(img, 0.5, 2.0)
      # else:
      #   img = tf.image.crop_to_bounding_box(img, 4, 4, 56, 56)

      # label = tf.string_to_number(label, tf.int32)
      # label = tf.cast(label, tf.uint8)

      img = img.eval()
      # label = label.eval()

      res_img.append(list(img))
      res_label.append(label)


  return np.array(res_img), np.array(res_label)



def get_data_mode(mode, _path, _num_classes):
  '''
  Args:
  mode: 'train' or 'val'
  '''

  filenames_labels = load_filenames_labels(mode, _path)
  random.shuffle(filenames_labels)

  res_img = []
  res_label = []


  for item in filenames_labels:

    filename = item[0]
    # print(type(item[1]))
    label = int(item[1])
    img = cv2.imread(filename)

    res_img.append(img.astype(np.float32))
    res_label.append(label)

  # res_img = np.concatenate(res_img, axis=0)
  # res_label = np.concatenate(res_label, axis=0)
  res_label = np.array(res_label, dtype=np.int32)
  res_img = np.reshape(res_img, [-1, 3, 64, 64])
  res_img = np.transpose(res_img, [0, 2, 3, 1])

  print(res_img[0].shape)
  return np.array(res_img), np.array(res_label)




